package com.religiontopresent.inheritance_distribution

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
